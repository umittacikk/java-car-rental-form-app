/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package newpackage;

/**
 *
 * @author mustafa
 */
public interface IFindRange {
    double findRange(double fuelConsumption, double fuelTank);
}
